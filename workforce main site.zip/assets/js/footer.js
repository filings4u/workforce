
document.addEventListener("DOMContentLoaded", initS4UFooter);

function initS4UFooter() {
  const target = document.getElementById("siteFooter");
  if (!target) return;

  const hasPageCTA = !!document.querySelector(
    "main .cta-panel, main [class*='final-cta'], main [class*='closing-cta']"
  );

  const cta = hasPageCTA ? "" : `
    <div class="container footer-cta">
      <div class="footer-cta-copy">
        <span class="footer-cta-label">Workforce Compliance Software</span>
        <strong>Ready to manage your program in one secure workspace?</strong>
        <p>Choose a monthly software plan for your employer, owner-operator, or C/TPA operation.</p>
      </div>
      <div class="footer-cta-actions">
        <a class="footer-button footer-button-secondary" href="contact.html">Contact Our Team</a>
        <a class="footer-button footer-button-primary" href="pricing.html">View Pricing</a>
      </div>
    </div>
  `;

  target.innerHTML = cta + `
    <div class="container footer-shell">
      <div class="footer-brand-area">
        <a class="footer-brand" href="index.html" aria-label="screenings4u Workforce Compliance home">
          <img src="images/logo.png" alt="screenings4u" class="footer-logo" loading="lazy" decoding="async">
        </a>
        <p class="footer-about">
          Workforce Compliance software for managing employees, DOT and non-DOT programs,
          testing workflows, random pools, documents, reporting, and compliance activity.
        </p>
        <div class="footer-contact">
          <a href="tel:7732457009"><span class="footer-contact-icon" aria-hidden="true">☎</span><span>(773) 245-7009</span></a>
          <a href="mailto:support@screenings4u.com"><span class="footer-contact-icon" aria-hidden="true">✉</span><span>support@screenings4u.com</span></a>
        </div>
        <span class="footer-availability">Serving customers nationwide</span>
      </div>

      <nav class="footer-links-grid" aria-label="Footer navigation">
        <div class="footer-col">
          <h4>Workforce Software</h4>
          <a href="platform.html">Platform</a>
          <a href="pricing.html">Pricing</a>
          <a href="employers.html">Employers</a>
          <a href="owner-operators.html">Owner-Operators</a>
          <a href="ctpa.html">C/TPAs</a>
        </div>

        <div class="footer-col">
          <h4>Platform</h4>
          <a href="platform.html#workforce">Workforce Management</a>
          <a href="platform.html#programs">DOT &amp; Non-DOT Programs</a>
          <a href="platform.html#random">Random Pools</a>
          <a href="platform.html#testing">Testing Management</a>
          <a href="platform.html#records">Documents &amp; Reporting</a>
        </div>

        <div class="footer-col">
          <h4>screenings4u Services</h4>
          <a href="https://screenings4u.com/services.html">Testing Services</a>
          <a href="https://screenings4u.com/dot-services.html">DOT Services</a>
          <a href="https://screenings4u.com/background-checks.html">Background Checks</a>
          <a href="https://screenings4u.com/consulting-services.html">Consulting</a>
          <a href="https://screenings4u.com/dot-specimen-collector-training.html">Training</a>
        </div>

        <div class="footer-col">
          <h4>Account &amp; Company</h4>
          <a href="https://app.screenings4u.com">Workforce Login</a>
          <a href="contact.html">Contact Sales</a>
          <a href="https://screenings4u.com/about-us.html">About screenings4u</a>
          <a href="https://screenings4u.com/faqs.html">FAQs</a>
          <a href="https://screenings4u.com/blog.html">Resources</a>
        </div>
      </nav>
    </div>

    <div class="container footer-bottom">
      <div class="footer-bottom-copy">
        <span class="footer-copyright">© <span id="footerYear"></span> screenings4u. All rights reserved.</span>
        <span class="footer-subsidiary">A Subsidiary of <a href="https://www.roselandcompanies.com/" target="_blank" rel="noopener noreferrer">Roseland Companies, LLC</a></span>
      </div>
      <nav class="footer-legal-links" aria-label="Legal links">
        <a href="https://screenings4u.com/terms.html">Terms of Use</a>
        <a href="https://screenings4u.com/privacy.html">Privacy Policy</a>
        <a href="https://screenings4u.com/cookie-policy.html">Cookie Policy</a>
        <a href="https://screenings4u.com/accessibility.html">Accessibility</a>
        <a href="https://screenings4u.com/disclaimer.html">Disclaimer</a>
      </nav>
      <a href="https://app.screenings4u.com" class="footer-admin-login">Workforce Login</a>
    </div>
  `;

  const y = document.getElementById("footerYear");
  if (y) y.textContent = new Date().getFullYear();
}
